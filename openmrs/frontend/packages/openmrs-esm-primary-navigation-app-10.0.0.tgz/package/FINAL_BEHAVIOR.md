# Left Navigation Final Behavior

## Overview
The left navigation now respects the `mode` parameter from `useLeftNav()` to determine whether the navigation is always open or user-toggleable.

## Behavior by Mode

### `mode: 'normal'` - Always Open
```tsx
useLeftNav({ name: 'my-nav', basePath: '/app', mode: 'normal' });
```

**Desktop:**
- ✅ Full sidebar (256px) **always visible**
- ❌ **No hamburger menu** in top nav
- ❌ User **cannot collapse** it

**Mobile/Tablet:**
- **Always shows hamburger menu**
- No navigation visible by default  
- Click hamburger → Full sidebar (256px) slides out as overlay panel
- Click outside panel or navigate → Panel closes automatically

**Use Case:** Apps that require full navigation to be always visible (e.g., main patient chart)

---

### `mode: 'collapsed'` - User Toggleable
```tsx
useLeftNav({ name: 'my-nav', basePath: '/app', mode: 'collapsed' });
```

**Desktop:**
- ✅ **Hamburger menu** visible in top nav
- Two user-controlled states:
  - **Closed (default)**: Icon rail (48px) visible
  - **Opened**: Full sidebar (256px) visible
- Click hamburger to toggle between states
- User preference saved to `localStorage` as `openmrs:leftNavExpanded`

**Mobile/Tablet:**
- **Always shows hamburger menu**
- No navigation visible by default
- Click hamburger → Full sidebar (256px) slides out as overlay panel
- Click outside panel or navigate → Panel closes automatically

**Use Case:** Apps where users may want to maximize screen space (e.g., forms, data entry)

---

### `mode: 'hidden'` - Not Shown
```tsx
useLeftNav({ name: 'my-nav', basePath: '/app', mode: 'hidden' });
```

- Navigation not displayed at all
- Content uses full width

---

## Technical Implementation

### State Management
- `mode` parameter controls **whether** navigation is toggleable
- `isNavExpanded` local state (in `navbar.component.tsx`) controls **current** open/closed state when `mode === 'collapsed'`
- User's toggle preference stored in `localStorage` with key `openmrs:leftNavExpanded`

### Component Flow
1. Page calls `useLeftNav({ mode: 'collapsed' })` or `useLeftNav({ mode: 'normal' })`
2. `mode` stored in `leftNavStore` (global framework store)
3. `HeaderItems` component reads `mode` from store
4. Hamburger button shown only when `mode === 'collapsed'`
5. `CustomLeftNav` component renders:
   - Icon rail (48px) when `mode === 'collapsed' && !isNavExpanded`
   - Full sidebar (256px) when `mode === 'normal' || (mode === 'collapsed' && isNavExpanded)`

### Body Classes
The body element gets classes for CSS adjustments:
- `omrs-left-nav-expanded`: When showing full sidebar (256px)
- `omrs-left-nav-collapsed`: When showing icon rail (48px)

These classes trigger content margin adjustments via `left-nav-global.scss`.

---

## Examples

### Example 1: Patient Chart (Always Open)
```tsx
function PatientChart() {
  useLeftNav({ 
    name: 'patient-chart-nav', 
    basePath: '/patient/:patientUuid/chart',
    mode: 'normal'  // Always show full nav
  });
  
  return <div>Chart content...</div>;
}
```
Result: Full navigation always visible, no way to collapse

### Example 2: Form Entry (User Toggleable)
```tsx
function FormEntry() {
  useLeftNav({ 
    name: 'form-nav', 
    basePath: '/form',
    mode: 'collapsed'  // Let user toggle
  });
  
  return <div>Form content...</div>;
}
```
Result: Icon rail by default, hamburger menu to expand when needed

---

## Migration from Old Behavior

**Old behavior:** Hamburger always visible, toggled between icon rail and full nav

**New behavior:** Hamburger visibility controlled by `mode` parameter

**Action needed:** 
- Apps that want always-open nav: specify `mode: 'normal'`
- Apps that want toggleable nav: specify `mode: 'collapsed'`
- Apps that don't specify mode: default is `'normal'` (always open)

---

## Files Modified

1. **navbar.component.tsx**
   - Added `isNavExpanded` local state
   - Hamburger shown only when `mode === 'collapsed'`
   - Hamburger toggles `isNavExpanded` state

2. **side-menu-panel.component.tsx**
   - Accepts `isNavExpanded` prop
   - Passes it to `CustomLeftNav`

3. **custom-left-nav.component.tsx**
   - Accepts `isNavExpanded` prop
   - Computes visual state based on `mode` and `isNavExpanded`
   - Sets appropriate body classes

4. **custom-left-nav.module.scss**
   - Styles for collapsed (48px) and expanded (256px) states

5. **left-nav-global.scss**
   - Content area margin adjustments

---

## Testing Checklist

- [ ] Normal mode: full sidebar always visible, no hamburger
- [ ] Collapsed mode: icon rail shown, hamburger visible
- [ ] Collapsed mode: clicking hamburger expands to full sidebar
- [ ] Collapsed mode: clicking hamburger again collapses to icon rail
- [ ] Collapsed mode: preference persists after page navigation
- [ ] Collapsed mode: preference persists after browser refresh
- [ ] Mobile: hamburger always visible (both modes)
- [ ] Mobile: no icon rail shown
- [ ] Mobile: hamburger opens full sidebar as overlay
- [ ] Mobile: clicking outside panel closes it
- [ ] Mobile: navigating to another page closes panel
- [ ] Content area margin adjusts correctly when toggling
- [ ] Smooth transitions between states
