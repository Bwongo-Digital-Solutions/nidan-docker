import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { InlineLoading, InlineNotification, Search, Tile } from '@carbon/react';
import {
  showSnackbar,
  useVisit,
  Workspace2,
  type Workspace2DefinitionProps,
} from '@openmrs/esm-framework';
import { useTranslation } from 'react-i18next';
import { useActiveVisits, type ActiveVisit } from '../../hooks/useActiveVisits';
import { useAdmitAndAssignToBed } from '../../hooks/useAdmitAndAssignToBed';
import { useInpatientAdmissionByPatients } from '../../hooks/useInpatientAdmissionByPatients';
import useRestPatient from '../../hooks/useRestPatient';
import useWardLocation from '../../hooks/useWardLocation';
import type { Bed } from '../../types';
import styles from './assign-bed.scss';

export interface AssignBedWorkspaceProps {
  bed: Bed;
}

const AssignBedWorkspace: React.FC<Workspace2DefinitionProps<AssignBedWorkspaceProps>> = ({
  workspaceProps: { bed },
}) => {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPatientUuid, setSelectedPatientUuid] = useState<string | null>(null);
  const { visits, isLoading, error } = useActiveVisits();

  const filteredVisits = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();
    if (!query) {
      return visits;
    }

    return visits.filter((visit) => {
              const name =
                visit.patient?.person?.preferredName?.display ??
                visit.patient?.person?.display ??
                visit.patient?.display;
              const identifiers = visit.patient?.identifiers?.map((id) => id.identifier).join(' ') ?? '';
              return `${name} ${identifiers}`.toLowerCase().includes(query);
    });
  }, [visits, searchTerm]);

  return (
    <Workspace2 title={t('assignBed', 'Assign bed {{bedNumber}}', { bedNumber: bed.bedNumber })}>
      <div className={styles.container}>
        <Search
          id="assign-bed-patient-search"
          labelText={t('searchPatients', 'Search patients')}
          placeholder={t('searchPatients', 'Search patients')}
          value={searchTerm}
          onChange={(event) => setSearchTerm(event.target.value)}
          size="lg"
        />
        {error ? (
          <InlineNotification
            kind="error"
            lowContrast
            hideCloseButton
            title={t('errorLoadingPatients', 'Error loading admitted patients')}
          />
        ) : null}
        {isLoading ? (
          <InlineLoading description={t('loading', 'Loading...')} />
        ) : filteredVisits.length === 0 ? (
          <p className={styles.emptyState}>{t('noActivePatients', 'No active patients found')}</p>
        ) : (
          <ul className={styles.patientList}>
            {filteredVisits.map((visit) => (
              <li key={visit.patient.uuid}>
                <PatientSearchResult
                  visit={visit}
                  disabled={Boolean(selectedPatientUuid)}
                  onSelect={() => setSelectedPatientUuid(visit.patient.uuid)}
                />
              </li>
            ))}
          </ul>
        )}
        {selectedPatientUuid ? (
          <AdmitSelectedPatient
            patientUuid={selectedPatientUuid}
            bed={bed}
            onReset={() => setSelectedPatientUuid(null)}
          />
        ) : null}
      </div>
    </Workspace2>
  );
};

const PatientSearchResult: React.FC<{ visit: ActiveVisit; disabled: boolean; onSelect: () => void }> = ({
  visit,
  disabled,
  onSelect,
}) => {
  const name =
    visit.patient?.person?.preferredName?.display ?? visit.patient?.person?.display ?? visit.patient?.display;
  const identifier = visit.patient?.identifiers?.[0]?.identifier;
  const location = visit.location?.display;

  return (
    <Tile
      className={styles.patientTile}
      onClick={disabled ? undefined : onSelect}
      role="button"
      tabIndex={disabled ? -1 : 0}
      onKeyDown={(event) => {
        if (disabled) {
          return;
        }
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          onSelect();
        }
      }}>
      <span className={styles.patientName}>{name}</span>
      {identifier ? <span className={styles.patientMeta}>{identifier}</span> : null}
      {location ? <span className={styles.patientMeta}>{location}</span> : null}
    </Tile>
  );
};

const AdmitSelectedPatient: React.FC<{ patientUuid: string; bed: Bed; onReset: () => void }> = ({
  patientUuid,
  bed,
  onReset,
}) => {
  const { t } = useTranslation();
  const { location } = useWardLocation();
  const { patient, isLoading: isLoadingPatient, error: errorLoadingPatient } = useRestPatient(patientUuid);
  const { activeVisit, isLoading: isLoadingVisit, error: errorLoadingVisit } = useVisit(patientUuid);
  const {
    data: inpatientAdmissions,
    isLoading: isLoadingAdmissions,
    error: errorLoadingAdmissions,
  } = useInpatientAdmissionByPatients([patientUuid]);
  const { admitAndAssign, isSubmitting } = useAdmitAndAssignToBed();
  const startedRef = useRef(false);

  const handleFailure = useCallback(
    (title: string, subtitle?: string) => {
      showSnackbar({
        kind: 'error',
        title,
        subtitle,
      });
      onReset();
    },
    [onReset],
  );

  useEffect(() => {
    if (startedRef.current) {
      return;
    }

    if (isLoadingPatient || isLoadingVisit || isLoadingAdmissions) {
      return;
    }

    if (errorLoadingPatient || errorLoadingVisit || errorLoadingAdmissions) {
      handleFailure(t('errorLoadingPatientInfo', 'Error loading patient info'));
      return;
    }

    if (!patient) {
      handleFailure(t('errorLoadingPatientInfo', 'Error loading patient info'));
      return;
    }

    if (!activeVisit) {
      showSnackbar({
        kind: 'warning',
        title: t('patienthasNoActiveVisit', 'Patient has no active visit'),
      });
      onReset();
      return;
    }

    const admission = inpatientAdmissions?.[0];
    if (admission?.currentInpatientLocation?.uuid === location?.uuid) {
      showSnackbar({
        kind: 'warning',
        title: t('patientAlreadyAdmittedToCurrentLocation', 'Patient already admitted to current location'),
      });
      onReset();
      return;
    }

    startedRef.current = true;
    admitAndAssign({
      patient,
      visit: activeVisit,
      dispositionType: admission ? 'TRANSFER' : 'ADMIT',
      bedId: bed.id,
      bedNumber: bed.bedNumber,
      onError: onReset,
    });
  }, [
    activeVisit,
    admitAndAssign,
    bed.bedNumber,
    bed.id,
    errorLoadingAdmissions,
    errorLoadingPatient,
    errorLoadingVisit,
    handleFailure,
    inpatientAdmissions,
    isLoadingAdmissions,
    isLoadingPatient,
    isLoadingVisit,
    location?.uuid,
    onReset,
    patient,
    t,
  ]);

  if (!isSubmitting && !isLoadingPatient && !isLoadingVisit && !isLoadingAdmissions) {
    return null;
  }

  return <InlineLoading description={t('admitting', 'Admitting...')} />;
};

export default AssignBedWorkspace;
