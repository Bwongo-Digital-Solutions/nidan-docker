import { useCallback, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  closeWorkspaceGroup2,
  showModal,
  showSnackbar,
  useAppContext,
  useConfig,
  useSession,
  type Patient,
  type Visit,
} from '@openmrs/esm-framework';
import type { WardConfigObject } from '../config-schema';
import type { DispositionType, WardViewContext } from '../types';
import { assignPatientToBed, removePatientFromBed, transferVisit, useAdmitPatient } from '../ward.resource';
import useWardLocation from './useWardLocation';

export interface AdmitAndAssignParams {
  patient: Patient;
  visit: Visit;
  dispositionType: DispositionType;
  bedId?: number;
  bedNumber?: string;
  assignedBedIdToRemove?: number;
  onSuccess?: () => void;
  onError?: () => void;
}

export function useAdmitAndAssignToBed() {
  const { t } = useTranslation();
  const { location } = useWardLocation();
  const { currentProvider } = useSession();
  const { admitPatient, emrConfiguration, isLoadingEmrConfiguration, errorFetchingEmrConfiguration } = useAdmitPatient();
  const { wardPatientGroupDetails } = useAppContext<WardViewContext>('ward-view-context') ?? {};
  const config = useConfig<WardConfigObject>();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleAdmissionSuccess = useCallback(
    (params: AdmitAndAssignParams) => {
      const bedLayoutNumber = wardPatientGroupDetails?.bedLayouts?.find((bed) => bed.bedId === params.bedId)?.bedNumber;
      const bedNumber = params.bedNumber ?? bedLayoutNumber;
      const patientName = params.patient?.person?.preferredName?.display ?? params.patient?.person?.display;

      if (params.bedId && bedNumber) {
        showSnackbar({
          kind: 'success',
          title: t('patientAdmittedSuccessfully', 'Patient admitted successfully'),
          subtitle: t(
            'patientAdmittedSuccessfullySubtitle',
            '{{patientName}} has been successfully admitted and assigned to bed {{bedNumber}}',
            {
              patientName,
              bedNumber,
            },
          ),
        });
      } else {
        showSnackbar({
          kind: 'success',
          title: t('patientAdmittedSuccessfully', 'Patient admitted successfully'),
          subtitle: t('patientAdmittedWoBed', 'Patient admitted successfully to {{location}}', {
            location: location?.display,
          }),
        });
      }

      params.onSuccess?.();
      closeWorkspaceGroup2();
      wardPatientGroupDetails?.mutate?.();
    },
    [location?.display, t, wardPatientGroupDetails],
  );

  const proceedWithAdmission = useCallback(
    (params: AdmitAndAssignParams, visitUuidToUse: string) => {
      setIsSubmitting(true);
      admitPatient(params.patient, params.dispositionType, visitUuidToUse)
        .then(
          async (response) => {
            if (response.ok) {
              if (params.bedId) {
                return assignPatientToBed(params.bedId, params.patient.uuid, response.data.uuid);
              }

              if (params.assignedBedIdToRemove) {
                return removePatientFromBed(params.assignedBedIdToRemove, params.patient.uuid);
              }

              return response;
            }
          },
          (err: Error) => {
            showSnackbar({
              kind: 'error',
              title: t('errorCreatingEncounter', 'Failed to admit patient'),
              subtitle: err.message,
            });
            params.onError?.();
          },
        )
        .then(
          (response) => {
            if (response && response?.ok) {
              handleAdmissionSuccess(params);
            }
          },
          () => {
            showSnackbar({
              kind: 'warning',
              title: t('patientAdmittedSuccessfully', 'Patient admitted successfully'),
              subtitle: t(
                'patientAdmittedButBedNotAssigned',
                'Patient admitted successfully but fail to assign bed to patient',
              ),
            });
          },
        )
        .finally(() => {
          setIsSubmitting(false);
        });
    },
    [admitPatient, handleAdmissionSuccess, t],
  );

  const admitAndAssign = useCallback(
    (params: AdmitAndAssignParams) => {
      const visitType = params.visit?.visitType;
      if (visitType && visitType.uuid !== config?.ipdVisitTypeUuid) {
        const visitTypeName = visitType.display;
        const dispose = showModal('visit-type-confirmation-modal', {
          close: () => dispose(),
          visitTypeName,
          onContinueWithCurrentVisit: () => {
            dispose();
            proceedWithAdmission(params, params.visit.uuid);
          },
          onConfirmNewVisit: async () => {
            dispose();
            try {
              setIsSubmitting(true);
              const transferResponse = await transferVisit({
                currentVisitUuid: params.visit.uuid,
                patientUuid: params.patient.uuid,
                newVisitTypeUuid: config.ipdVisitTypeUuid,
                newLocationUuid: location.uuid,
                admissionEncounterTypeUuid: emrConfiguration.admissionEncounterType.uuid,
                visitProviderUuid: currentProvider?.uuid,
                bedId: params.bedId,
              });

              if (transferResponse && transferResponse.ok) {
                handleAdmissionSuccess(params);
              } else {
                throw new Error('Failed to transfer visit');
              }
            } catch (error) {
              setIsSubmitting(false);
              showSnackbar({
                kind: 'error',
                title: t('errorCreatingVisit', 'Failed to start new IPD visit'),
                subtitle: error?.message,
              });
              params.onError?.();
            }
          },
        });
      } else {
        proceedWithAdmission(params, params.visit?.uuid);
      }
    },
    [
      config.ipdVisitTypeUuid,
      currentProvider?.uuid,
      emrConfiguration?.admissionEncounterType?.uuid,
      handleAdmissionSuccess,
      location?.uuid,
      proceedWithAdmission,
      t,
    ],
  );

  return {
    admitAndAssign,
    isSubmitting,
    isLoadingEmrConfiguration,
    errorFetchingEmrConfiguration,
  };
}
