import { useMemo } from 'react';
import useSWR from 'swr';
import { type FetchResponse, openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';

const visitRepresentation =
  'custom:(uuid,startDatetime,location:(uuid,display),patient:(uuid,display,identifiers:(identifier),person:(uuid,display,gender,birthdate,preferredName:(display))))';

export interface ActiveVisitPerson {
  uuid: string;
  display: string;
  gender?: string;
  birthdate?: string;
  preferredName?: { display: string };
}

export interface ActiveVisitPatient {
  uuid: string;
  display: string;
  identifiers?: Array<{ identifier: string }>;
  person?: ActiveVisitPerson;
}

export interface ActiveVisit {
  uuid: string;
  startDatetime: string;
  location?: { uuid: string; display: string } | null;
  patient: ActiveVisitPatient;
}

interface VisitResponse {
  results: Array<ActiveVisit>;
}

function dedupeByPatient(visits: ActiveVisit[]): ActiveVisit[] {
  const latestByPatient = new Map<string, ActiveVisit>();

  visits.forEach((visit) => {
    const patientUuid = visit.patient?.uuid;
    if (!patientUuid) {
      return;
    }

    const existing = latestByPatient.get(patientUuid);
    if (!existing || new Date(visit.startDatetime) > new Date(existing.startDatetime)) {
      latestByPatient.set(patientUuid, visit);
    }
  });

  return Array.from(latestByPatient.values());
}

export function useActiveVisits() {
  const apiUrl = `${restBaseUrl}/visit?includeInactive=false&v=${visitRepresentation}&limit=40`;
  const { data, error, isLoading } = useSWR<FetchResponse<VisitResponse>, Error>(apiUrl, openmrsFetch);

  const visits = useMemo(() => dedupeByPatient(data?.data?.results ?? []), [data]);

  return {
    visits,
    isLoading,
    error,
  };
}
