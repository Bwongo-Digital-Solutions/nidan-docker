import { ExtensionSlot, useLeftNav, useConfig, registerExtensionSlot } from '@openmrs/esm-framework';
import classNames from 'classnames';
import React, { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { spaBasePath, moduleName } from '../constants';
import Loader from '../loader/loader.component';
import ChartReview from '../patient-chart/chart-review/chart-review.component';
import SideMenuPanel from '../side-nav/side-menu.component';
import TopNavTabBar from './top-nav/top-nav-tab-bar.component';
import { type LayoutMode } from './chart-review/dashboard-view.component';
import { type ChartConfig } from '../config-schema';
import styles from './patient-chart.scss';
import { usePatientChartPatientAndVisit } from './patient-chart.resources';

const PatientChart: React.FC = () => {
  const { patientUuid, view: encodedView } = useParams();

  // specify key to ensure that WrapPatientChart instance is re-created
  // when we switch patient
  return <WrappedPatientChart key={patientUuid} patientUuid={patientUuid} encodedView={encodedView} />;
};

interface WrappedPatientChartProps {
  patientUuid: string;
  encodedView: string;
}

// Inner component that uses useLeftNav — only rendered when menuPosition === 'side'
const SideNavPatientChart: React.FC<WrappedPatientChartProps & { view: string }> = ({
  patientUuid,
  view,
}) => {
  const leftNavBasePath = useMemo(() => spaBasePath.replace(':patientUuid', patientUuid), [patientUuid]);
  useLeftNav({ name: 'patient-chart-dashboard-slot', basePath: leftNavBasePath, mode: 'collapsed' });
  return <SideMenuPanel />;
};

const WrappedPatientChart: React.FC<WrappedPatientChartProps> = ({ patientUuid, encodedView }) => {
  const view = decodeURIComponent(encodedView);
  const [layoutMode, setLayoutMode] = useState<LayoutMode>();
  const state = usePatientChartPatientAndVisit(patientUuid);
  const { isLoadingPatient, patient } = state;
  const { menuPosition } = useConfig<ChartConfig>();

  const isTopNav = menuPosition === 'top';

  // When using top-nav we skip useLeftNav entirely (it mounts the side nav).
  // We still need patient-chart-dashboard-slot registered so the extension
  // store populates — register it directly on mount.
  useEffect(() => {
    if (isTopNav) {
      registerExtensionSlot(moduleName, 'patient-chart-dashboard-slot');
    }
  }, [isTopNav]);

  return (
    <>
      {/* Side-nav mode: mounts useLeftNav + SideMenuPanel */}
      {!isTopNav && <SideNavPatientChart patientUuid={patientUuid} encodedView={encodedView} view={view} />}

      <main
        className={classNames('omrs-main-content', styles.chartContainer, {
          [styles.chartContainerTopNav]: isTopNav,
        })}
      >
        <div className={classNames(styles.innerChartContainer)}>
          {isLoadingPatient ? (
            <Loader />
          ) : (
            <>
              <aside>
                <ExtensionSlot name="patient-header-slot" state={state} />
                <ExtensionSlot name="patient-info-slot" state={state} className={styles.patientInfoSlot} />
              </aside>
              {isTopNav && <TopNavTabBar patientUuid={patientUuid} currentView={view} />}
              <div className={styles.grid}>
                <div
                  className={classNames(styles.chartReview, { [styles.widthContained]: layoutMode === 'anchored' })}
                >
                  <ChartReview
                    patient={patient}
                    patientUuid={patientUuid}
                    view={view}
                    setDashboardLayoutMode={setLayoutMode}
                  />
                </div>
              </div>
            </>
          )}
        </div>
      </main>
    </>
  );
};

export default PatientChart;
