import { useEffect, useRef, useState } from 'react';

export interface DashboardLinkInfo {
  path: string;
  title: string;
  icon: string | undefined;
}

/**
 * Reads rendered anchor/link elements from the hidden extension slot container
 * to extract title and icon for every dashboard link — works for ALL apps
 * regardless of whether they use createDashboardLink or their own component.
 *
 * Each DashboardExtension renders:
 *   <a class="cds--side-nav__link" href=".../patient-uuid/chart/{path}">
 *     <span class="menu">
 *       <svg .../>   ← icon (omrs-icon svg, may be absent)
 *       <span>{title}</span>
 *     </span>
 *   </a>
 *
 * We also read the icon from the SVG title element or aria-label if present.
 */
export function useDashboardLinkInfo(containerRef: React.RefObject<HTMLDivElement>): Map<string, DashboardLinkInfo> {
  const [linkInfoMap, setLinkInfoMap] = useState<Map<string, DashboardLinkInfo>>(new Map());
  const observerRef = useRef<MutationObserver | null>(null);

  useEffect(() => {
    function scrape() {
      const container = containerRef.current;
      if (!container) return;

      const anchors = container.querySelectorAll<HTMLAnchorElement>('a.cds--side-nav__link, a[href*="/chart/"]');
      if (!anchors.length) return;

      const map = new Map<string, DashboardLinkInfo>();

      anchors.forEach((anchor) => {
        // Extract path from href: last segment after /chart/
        const href = anchor.getAttribute('href') ?? '';
        const chartMatch = href.match(/\/chart\/([^/]+)/);
        if (!chartMatch) return;
        const path = decodeURIComponent(chartMatch[1]);

        // Extract title: the last <span> inside the link (the text span, not the icon span)
        const spans = anchor.querySelectorAll('span');
        let title = '';
        // Prefer the deepest non-empty span that doesn't contain child elements
        spans.forEach((span) => {
          if (!span.querySelector('span, svg') && span.textContent?.trim()) {
            title = span.textContent.trim();
          }
        });
        // Fallback to full text content
        if (!title) {
          title = anchor.textContent?.trim() ?? path;
        }

        // Extract icon: look for svg use[href] or title inside the svg, or data-icon attribute
        let icon: string | undefined;
        const svg = anchor.querySelector('svg');
        if (svg) {
          // omrs icons set a data-icon attribute or use href on the <use> element
          const useEl = svg.querySelector('use');
          const iconHref = useEl?.getAttribute('href') ?? useEl?.getAttribute('xlink:href') ?? '';
          const iconMatch = iconHref.match(/#(omrs-icon-[^"]+)/);
          if (iconMatch) {
            icon = iconMatch[1];
          }
        }

        map.set(path, { path, title, icon });
      });

      if (map.size > 0) {
        setLinkInfoMap(map);
      }
    }

    const container = containerRef.current;
    if (!container) return;

    // Initial scrape
    scrape();

    // Watch for DOM changes (extensions mount asynchronously)
    observerRef.current = new MutationObserver(scrape);
    observerRef.current.observe(container, { childList: true, subtree: true, characterData: true });

    return () => {
      observerRef.current?.disconnect();
    };
  }, [containerRef]);

  return linkInfoMap;
}
