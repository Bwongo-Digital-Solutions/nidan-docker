import { InlineNotification } from '@carbon/react';
import { ExtensionSlot, useDefineAppContext, useSession, type Location } from '@openmrs/esm-framework';
import React, { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useWardConfig } from './ward-view.resource';
import { getDefaultWardLocation, useWardLocations } from '../hooks/useWardLocations';
import WardViewTabs from './ward-tabs.component';
import { WardPageHeader } from '../header/ward-header.component';
import styles from './ward-view.scss';

export interface WardLocationContext {
  location: Location;
}

const WardView: React.FC<{}> = () => {
  const { t } = useTranslation();
  const { sessionLocation } = useSession();
  const { wardLocations, parentWardLocations, locationsByUuid, isLoading: isLoadingLocations } = useWardLocations();
  const [selectedLocation, setSelectedLocation] = useState<Location>(sessionLocation);
  const [viewMode, setViewMode] = useState<'card' | 'list'>('card');
  const [selectedBedType, setSelectedBedType] = useState<string>('all');

  useEffect(() => {
    if (!isLoadingLocations && wardLocations.length > 0) {
      const sessionIsAdmissionLocation = wardLocations.some((loc) => loc.uuid === sessionLocation?.uuid);
      if (!sessionIsAdmissionLocation) {
        const defaultLocation = getDefaultWardLocation(parentWardLocations, locationsByUuid);
        if (defaultLocation) {
          setSelectedLocation(defaultLocation as unknown as Location);
        }
      }
    }
  }, [isLoadingLocations, wardLocations, parentWardLocations, locationsByUuid, sessionLocation]);

  useDefineAppContext<WardLocationContext & { viewMode: string; selectedBedType: string }>('ward-location-context', {
    location: selectedLocation,
    viewMode,
    selectedBedType,
  });

  const locationUuid = selectedLocation?.uuid;
  const wardConfig = useWardConfig(locationUuid);

  const handleLocationChange = useCallback((location: Location) => {
    setSelectedLocation(location);
  }, []);

  if (!selectedLocation) {
    return <InlineNotification kind="error" title={t('invalidLocationSpecified', 'Invalid location specified')} />;
  }

  const wardId = wardConfig.id;

  return (
    <div className={styles.wardView}>
      <WardPageHeader />
      <WardViewTabs
        selectedLocation={selectedLocation}
        onLocationChange={handleLocationChange}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        selectedBedType={selectedBedType}
        onBedTypeChange={setSelectedBedType}
      />
      <ExtensionSlot name={wardId} />
    </div>
  );
};

export default WardView;
