import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { useConfig } from '@openmrs/esm-framework';
import { dashboardPath, spaRoot, basePath } from './constants';
import { type ChartConfig } from './config-schema';
import PatientChart from './patient-chart/patient-chart.component';
import { getAssignedExtensions } from "@openmrs/esm-framework";


import styles from './root.scss';

export default function Root() {
  const extensions = getAssignedExtensions("patient-chart-dashboard-slot");
  console.table(
  extensions.map((extension) => ({
    id: extension.id,

    meta: JSON.stringify(extension.meta),
  })),
);
  const { menuPosition } = useConfig<ChartConfig>();
  const isTopNav = menuPosition === 'top';

  return (
    <>
      <div className={isTopNav ? styles.patientChartWrapperTopNav : styles.patientChartWrapper}>
        <BrowserRouter basename={spaRoot}>
          <Routes>
            <Route path={basePath} element={<PatientChart />} />
            <Route path={dashboardPath} element={<PatientChart />} />
          </Routes>
        </BrowserRouter>
      </div>
    </>
  );
}

/**
 * DO NOT REMOVE THIS COMMENT
 * THE TRANSLATION KEYS AND VALUES USED IN THE COMMON LIB IS WRITTEN HERE
 * t('paginationPageText', 'of {{count}} pages', {count})
 * t("emptyStateText", 'There are no {{displayText}} to display for this patient', {displayText: "sample text"})
 * t('record', 'Record')
 * t('errorCopy','Sorry, there was a problem displaying this information. You can try to reload this page, or contact the site administrator and quote the error code above.')
 * t('error', 'Error')
 * t('seeAll', 'See all')
 * t('paginationItemsCount', `{{pageItemsCount}} / {{count}} items`, { count: totalItems, pageItemsCount });
 * t('Routine')
 * t('Stat')
 * t('On scheduled date')
 */
