import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Tab, TabList, Tabs } from '@carbon/react';
import { type ConfigObject, ExtensionSlot, MaybeIcon, registerExtensionSlot, useExtensionStore } from '@openmrs/esm-framework';
import { dashboardLinkRegistry } from '@openmrs/esm-patient-common-lib';
import { type DashboardConfig } from '../chart-review/dashboard-view.component';
import { basePath as chartBasePath, spaBasePath } from '../../constants';
import styles from './top-nav-tab-bar.scss';

// ─── helpers ─────────────────────────────────────────────────────────────────

function isDashboardConfig(obj: unknown): obj is DashboardConfig {
  return (
    typeof obj === 'object' &&
    obj !== null &&
    'path' in obj &&
    typeof (obj as DashboardConfig).path === 'string' &&
    'slot' in obj &&
    typeof (obj as DashboardConfig).slot === 'string'
  );
}

const seenMessages = new Set<string>();

function getDashboardDefinition(meta: object, config: ConfigObject, moduleName: string, name: string) {
  const merged = { ...meta, ...config, moduleName };
  if (isDashboardConfig(merged)) return merged;
  const msg = `TopNavTabBar: no valid dashboard definition for "${name}" in ${moduleName}`;
  if (!seenMessages.has(msg)) { console.error(msg); seenMessages.add(msg); }
  return null;
}

// ─── hook: scrape rendered anchor elements from the hidden slot container ─────

interface ScrapedLinkInfo {
  title: string;
  icon: string | undefined;
}

function useScrapedLinkInfo(containerRef: React.RefObject<HTMLDivElement>): Map<string, ScrapedLinkInfo> {
  const [map, setMap] = useState<Map<string, ScrapedLinkInfo>>(new Map());

  const scrape = useCallback(() => {
    const container = containerRef.current;
    if (!container) return;
    const anchors = container.querySelectorAll<HTMLAnchorElement>('a');
    if (!anchors.length) return;

    const next = new Map<string, ScrapedLinkInfo>();
    anchors.forEach((anchor) => {
      // path is the last URL segment after /chart/
      const href = anchor.getAttribute('href') ?? '';
      const m = href.match(/\/chart\/([^/?#]+)/);
      if (!m) return;
      const path = decodeURIComponent(m[1]);

      // title: deepest non-container span (the text leaf)
      let title = '';
      anchor.querySelectorAll('span').forEach((span) => {
        if (!span.querySelector('span, svg') && span.textContent?.trim()) {
          title = span.textContent.trim();
        }
      });
      if (!title) title = anchor.textContent?.trim() ?? path;

      // icon: look for data-icon on the svg, or parse the <use> href
      let icon: string | undefined;
      const svg = anchor.querySelector('svg');
      if (svg) {
        icon = svg.getAttribute('data-icon') ?? undefined;
        if (!icon) {
          const useEl = svg.querySelector('use');
          const ref = useEl?.getAttribute('href') ?? useEl?.getAttribute('xlink:href') ?? '';
          const im = ref.match(/#(omrs-icon-[\w-]+)/);
          if (im) icon = im[1];
        }
      }

      next.set(path, { title, icon });
    });

    if (next.size > 0) setMap(next);
  }, [containerRef]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    scrape();
    const obs = new MutationObserver(scrape);
    obs.observe(container, { childList: true, subtree: true, characterData: true });
    return () => obs.disconnect();
  }, [containerRef, scrape]);

  return map;
}

// ─── component ────────────────────────────────────────────────────────────────

interface TopNavTabBarProps {
  patientUuid: string;
  currentView: string;
}

const TopNavTabBar: React.FC<TopNavTabBarProps> = ({ patientUuid, currentView }) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const extensionStore = useExtensionStore();

  // Hidden container where we render the full extension slot to scrape link info
  const hiddenRef = useRef<HTMLDivElement>(null);
  const scrapedInfo = useScrapedLinkInfo(hiddenRef);

  // Router-relative path for useNavigate (BrowserRouter has basename=spaRoot,
  // so navigate() must NOT include the spaBase prefix — it would double it).
  const routerPath = useMemo(() => chartBasePath.replace(':patientUuid', patientUuid), [patientUuid]);

  // Absolute path for the hidden slot state so DashboardExtension generates
  // correct hrefs that we can scrape for title/icon.
  const absoluteBasePath = useMemo(() => spaBasePath.replace(':patientUuid', patientUuid), [patientUuid]);

  // Flat ordered list of dashboards — same logic as chart-review.component.tsx
  const dashboards = useMemo<DashboardConfig[]>(() => {
    if (!('patient-chart-dashboard-slot' in extensionStore.slots)) return [];

    return extensionStore.slots['patient-chart-dashboard-slot'].assignedExtensions
      .flatMap((e) => {
        if (e.config?.slotName) {
          if (e.config.slotName in extensionStore.slots) {
            return extensionStore.slots[e.config.slotName].assignedExtensions.map((sub) =>
              getDashboardDefinition(sub.meta, sub.config, sub.moduleName, sub.name),
            );
          } else {
            registerExtensionSlot('@openmrs/esm-patient-chart-app', e.config.slotName);
            throw Promise.resolve();
          }
        }
        return getDashboardDefinition(e.meta, e.config, e.moduleName, e.name);
      })
      .filter(Boolean) as DashboardConfig[];
  }, [extensionStore]);

  const selectedIndex = useMemo(() => {
    const idx = dashboards.findIndex((d) => d.path === currentView);
    return idx >= 0 ? idx : 0;
  }, [dashboards, currentView]);

  if (!dashboards.length) return null;

  return (
    <>
      {/*
       * Hidden slot render: gives every extension component (including external ones)
       * a chance to mount and render its DashboardExtension link so we can scrape
       * the title text and icon from the resulting DOM.
       */}
      <div ref={hiddenRef} aria-hidden="true" style={{ position: 'absolute', visibility: 'hidden', pointerEvents: 'none', height: 0, overflow: 'hidden' }}>
        <ExtensionSlot name="patient-chart-dashboard-slot" state={{ basePath: absoluteBasePath }} />
      </div>

      <nav className={styles.topNavTabBar} aria-label={t('patientChartNavigation', 'Patient chart navigation')}>
        <Tabs
          selectedIndex={selectedIndex}
          onChange={({ selectedIndex: idx }) => {
            const target = dashboards[idx];
            if (target) navigate(`${routerPath}/${encodeURIComponent(target.path)}`);
          }}
        >
          <TabList
            aria-label={t('patientChartTabs', 'Patient chart tabs')}
            className={styles.tabList}
            scrollIntoView
            contained={false}
          >
            {dashboards.map((dashboard) => {
              // Resolution priority:
              // 1. dashboardLinkRegistry — fast path for packages using createDashboardLink
              // 2. scraped DOM — works for all external apps
              // 3. raw path slug — last resort fallback
              const fromRegistry = dashboardLinkRegistry.get(dashboard.path);
              const fromDom = scrapedInfo.get(dashboard.path);

              const title = fromRegistry?.title ?? fromDom?.title ?? dashboard.path;
              const icon = fromRegistry?.icon ?? fromDom?.icon ?? (dashboard as any).icon;

              return (
                <Tab key={dashboard.path} className={styles.tab} id={`patient-chart-tab-${dashboard.path}`}>
                  <span className={styles.tabContent}>
                    {icon && <MaybeIcon icon={icon} size={16} className={styles.tabIcon} />}
                    <span>{t(title, title)}</span>
                  </span>
                </Tab>
              );
            })}
          </TabList>
        </Tabs>
      </nav>
    </>
  );
};

export default TopNavTabBar;
