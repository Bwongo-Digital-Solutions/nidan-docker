# Left Navigation Redesign

## Overview
The left navigation has been redesigned to support a collapsible icon rail while maintaining compatibility with existing extensions and navigation patterns.

## Key Changes

### 1. New Custom Left Navigation Component
**Location:** `src/components/left-nav/custom-left-nav.component.tsx`

Replaces the Carbon Design System's `SideNav` with a custom implementation that supports:
- **Collapsed mode**: 48px icon rail showing only icons
- **Expanded mode**: 256px panel showing icons with titles
- **Hidden mode**: Navigation not displayed

### 2. Hamburger Menu Integration
**Modified:** `src/components/navbar/navbar.component.tsx`

The hamburger menu button now:
- Only shows in desktop mode (instead of mobile/tablet)
- Toggles between collapsed and expanded states
- Shows active state when navigation is expanded
- Saves user preference to localStorage

### 3. Persistent User Preference
User's navigation mode preference is:
- Saved to `localStorage` with key `openmrs:leftNavMode`
- Restored automatically when navigating between pages
- Persists across browser sessions

### 4. Updated Side Menu Panel
**Modified:** `src/components/navbar-header-panels/side-menu-panel.component.tsx`

Now uses `CustomLeftNav` instead of the framework's `LeftNavMenu`:
- Desktop: Always renders nav (mode determines collapsed/expanded)
- Mobile/Tablet: Shows as slide-out panel when hamburger clicked

## File Structure

```
src/components/left-nav/
├── custom-left-nav.component.tsx      # Main nav component
├── custom-left-nav.module.scss        # Nav styles
├── nav-toggle-button.component.tsx    # Toggle button (not currently used)
├── nav-toggle-button.module.scss      # Toggle button styles
├── left-nav-global.scss               # Global styles for content margins
├── index.ts                           # Exports
└── README.md                          # Documentation
```

## Styling

### Icon Rail (Collapsed Mode)
- Width: 48px
- Shows centered icons only
- Hover tooltips show full title
- Active indicator: 3px left border
- Background highlight for active item

### Full Navigation (Expanded Mode)  
- Width: 256px
- Shows icons (16px) with text labels
- Active indicator: 3px left border
- Background highlight for active item
- Text truncates with ellipsis if too long

### Content Area Adjustment
Main content (`#omrs-apps-container`) automatically adjusts its left margin:
- Collapsed: 48px margin
- Expanded: 256px margin
- Smooth transitions when toggling

## Behavior

### Desktop
1. Navigation always visible (unless hidden mode)
2. Hamburger button toggles collapsed ↔ expanded
3. User preference persists across pages

### Mobile/Tablet
1. Navigation hidden by default
2. Hamburger shows slide-out panel
3. Panel dismissed when clicking outside or navigating

## Compatibility

### No Changes Required For:
- Existing page components using `useLeftNav`
- Existing dashboard extensions
- Extension slot configurations
- Navigation icons and titles

### Framework Components Used:
- Uses framework's `useLeftNavStore` for state
- Uses framework's `setLeftNav` for updates  
- Uses framework's `ExtensionSlot` for rendering
- Maintains compatibility with `ComponentContext`

## Migration Notes

This implementation:
- ✅ Only modifies `esm-primary-navigation-app`
- ✅ Does not require changes to framework packages
- ✅ Does not require changes to other apps
- ✅ Maintains backward compatibility
- ✅ Works with existing dashboard extensions

## Testing

To test the new navigation:

1. **Start the app** and navigate to a page with left nav
2. **Verify icon rail** shows by default (collapsed mode)
3. **Click hamburger** to expand navigation
4. **Verify persistence** by navigating to another page
5. **Click hamburger** to collapse back to icon rail
6. **Refresh page** and verify preference is restored

## Future Enhancements

Possible improvements:
- Add animation/transition effects
- Support keyboard shortcuts for toggling
- Add accessibility announcements for mode changes
- Support per-app default modes
- Add tooltip position adjustment for screen edges
