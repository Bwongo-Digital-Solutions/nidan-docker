import { type EmrApiConfigurationResponse } from '../src/hooks/useEmrConfiguration';

export const emrConfigurationMock: EmrApiConfigurationResponse = {
  clinicianEncounterRole: { uuid: '240b26f9-dd88-4172-823d-4a8bfeb7841f' },
  consultFreeTextCommentsConcept: { uuid: '162169AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA' },
  visitNoteEncounterType: { uuid: 'd7151f82-c1f3-4152-a605-2f9ea7414a79' },
  admissionEncounterType: { uuid: 'e8151f82-c1f3-4152-a605-2f9ea7414a79' },
  inpatientNoteEncounterType: { uuid: 'f8151f82-c1f3-4152-a605-2f9ea7414a79' },
  transferRequestEncounterType: { uuid: 'g8151f82-c1f3-4152-a605-2f9ea7414a79' },
};
