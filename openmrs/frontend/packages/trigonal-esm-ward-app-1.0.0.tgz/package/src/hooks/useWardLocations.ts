import { type FetchResponse, openmrsFetch, restBaseUrl, useConfig } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { useMemo } from 'react';
import type { WardConfigObject } from '../config-schema';

export interface WardLocationRef {
  uuid: string;
  display: string;
}

export interface WardLocation {
  uuid: string;
  display: string;
  parentLocation?: WardLocationRef | null;
  childLocations?: Array<WardLocationRef>;
}

interface LocationResponse {
  results: Array<WardLocation>;
}

export function getAdmissionChildLocations(
  parent: WardLocation | undefined,
  locationsByUuid: Map<string, WardLocation>,
): WardLocation[] {
  if (!parent?.childLocations?.length) {
    return [];
  }

  return parent.childLocations
    .map((child) => locationsByUuid.get(child.uuid))
    .filter((child): child is WardLocation => Boolean(child));
}

export function getDefaultWardLocation(parentWardLocations: WardLocation[], locationsByUuid: Map<string, WardLocation>) {
  const firstParent = parentWardLocations[0];
  if (!firstParent) {
    return undefined;
  }

  const children = getAdmissionChildLocations(firstParent, locationsByUuid);
  return children[0] ?? firstParent;
}

/**
 * Fetches all locations tagged as admission locations.
 * These are rendered as ward tabs at the top of the ward view.
 */
export function useWardLocations() {
  const { admissionLocationTagName } = useConfig<WardConfigObject>();
  const apiUrl = admissionLocationTagName
    ? `${restBaseUrl}/location?tag=${encodeURIComponent(admissionLocationTagName)}&v=default`
    : null;

  const { data, error, isLoading } = useSWR<FetchResponse<LocationResponse>, Error>(apiUrl, openmrsFetch);

  const wardLocations = useMemo(() => data?.data?.results ?? [], [data]);

  const { locationsByUuid, parentWardLocations } = useMemo(() => {
    const byUuid = new Map(wardLocations.map((location) => [location.uuid, location]));
    const parents = wardLocations.filter((location) => {
      const parentUuid = location.parentLocation?.uuid;
      return !parentUuid || !byUuid.has(parentUuid);
    });

    return { locationsByUuid: byUuid, parentWardLocations: parents };
  }, [wardLocations]);

  return {
    wardLocations,
    parentWardLocations,
    locationsByUuid,
    isLoading,
    error,
  };
}

export function useWardLocation(q?: string) {
  const { admissionLocationTagName } = useConfig<WardConfigObject>();
  const apiUrl = admissionLocationTagName
    ? `${restBaseUrl}/location?tag=${encodeURIComponent(admissionLocationTagName)}&v=default${
        q ? `&q=${encodeURIComponent(q)}` : ''
      }`
    : null;

  const { data, error, isLoading } = useSWR<FetchResponse<LocationResponse>, Error>(apiUrl, openmrsFetch);

  const wardLocations = useMemo(() => data?.data?.results ?? [], [data]);

  return {
    wardLocations,
    isLoading,
    error,
  };
}
