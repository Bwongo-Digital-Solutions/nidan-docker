import React, { useCallback, useMemo } from 'react';
import { ContentSwitcher, Tab, TabList, Tabs, TabsSkeleton, IconSwitch, Select, SelectItem } from '@carbon/react';
import { Copy, Table } from '@carbon/react/icons';
import { type Location } from '@openmrs/esm-framework';
import { useTranslation } from 'react-i18next';
import { getAdmissionChildLocations, useWardLocations, type WardLocation } from '../hooks/useWardLocations';
import { useBedTypes } from '../hooks/useBedTypes';
import { useWardPatientGrouping } from '../hooks/useWardPatientGrouping';
import styles from './ward-tabs.scss';

interface WardViewTabsProps {
  selectedLocation: Location;
  onLocationChange: (location: Location) => void;
  viewMode: 'card' | 'list';
  onViewModeChange: (viewMode: 'card' | 'list') => void;
  selectedBedType: string;
  onBedTypeChange: (bedType: string) => void;
}

const WardViewTabs: React.FC<WardViewTabsProps> = ({
  selectedLocation,
  onLocationChange,
  viewMode,
  onViewModeChange,
  selectedBedType,
  onBedTypeChange,
}) => {
  const { t } = useTranslation();
  const { parentWardLocations, locationsByUuid, isLoading, error } = useWardLocations();
  const { bedTypes } = useBedTypes();
  const { bedLayouts } = useWardPatientGrouping();

  const { totalCounts, bedTypeCounts } = useMemo(() => {
    const typeCounts = new Map<string, { occupied: number; total: number }>();
    let totalOccupied = 0;
    let totalBeds = 0;

    bedLayouts?.forEach((bl) => {
      const isOccupied = bl.patients?.length > 0;
      totalBeds++;
      if (isOccupied) {
        totalOccupied++;
      }

      const typeUuid = bl.bedType?.uuid;
      if (typeUuid) {
        const current = typeCounts.get(typeUuid) || { occupied: 0, total: 0 };
        typeCounts.set(typeUuid, {
          occupied: current.occupied + (isOccupied ? 1 : 0),
          total: current.total + 1,
        });
      }
    });

    return {
      totalCounts: { occupied: totalOccupied, total: totalBeds },
      bedTypeCounts: typeCounts,
    };
  }, [bedLayouts]);

  const selectedParentIndex = useMemo(() => {
    if (!selectedLocation || !parentWardLocations.length) {
      return 0;
    }

    const selectedWard = locationsByUuid.get(selectedLocation.uuid);
    const parentUuid = selectedWard?.parentLocation?.uuid ?? selectedLocation.uuid;
    const index = parentWardLocations.findIndex((loc) => loc.uuid === parentUuid);
    return index >= 0 ? index : 0;
  }, [selectedLocation, parentWardLocations, locationsByUuid]);

  const selectedParent = parentWardLocations[selectedParentIndex];
  const childLocations = useMemo(
    () => getAdmissionChildLocations(selectedParent, locationsByUuid),
    [selectedParent, locationsByUuid],
  );

  const selectedChildIndex = useMemo(() => {
    if (!selectedLocation || !childLocations.length) {
      return 0;
    }

    const index = childLocations.findIndex((loc) => loc.uuid === selectedLocation.uuid);
    return index >= 0 ? index : 0;
  }, [selectedLocation, childLocations]);

  const selectWard = useCallback(
    (ward: WardLocation) => {
      if (ward.uuid !== selectedLocation?.uuid) {
        onLocationChange(ward as unknown as Location);
      }
    },
    [selectedLocation, onLocationChange],
  );

  const handleParentTabChange = useCallback(
    (evt: { selectedIndex: number }) => {
      const parent = parentWardLocations[evt.selectedIndex];
      if (!parent) {
        return;
      }

      const children = getAdmissionChildLocations(parent, locationsByUuid);
      selectWard(children[0] ?? parent);
    },
    [parentWardLocations, locationsByUuid, selectWard],
  );

  const handleChildTabChange = useCallback(
    (evt: { selectedIndex: number }) => {
      const child = childLocations[evt.selectedIndex];
      if (child) {
        selectWard(child);
      }
    },
    [childLocations, selectWard],
  );

  if (error) {
    return null;
  }

  if (isLoading) {
    return (
      <div className={styles.wardTabsContainer}>
        <TabsSkeleton />
      </div>
    );
  }

  return (
    <div className={styles.wardTabsContainer}>
      <div className={styles.tabsHeaderRow}>
        <div className={styles.wardTabs}>
          <Tabs selectedIndex={selectedParentIndex} onChange={handleParentTabChange}>
            <TabList className={styles.wardTabList} aria-label={t('wardTabs', 'Ward tabs')} contained>
              {parentWardLocations.map((ward) => (
                <Tab key={ward.uuid}>{ward.display}</Tab>
              ))}
            </TabList>
          </Tabs>
        </div>
        <div className={styles.controlsContainer}>
          <div className={styles.bedTypeSelector}>
            <Select
              id="bed-type-select"
              labelText={t('bedType', 'Bed Type')}
              hideLabel
              size="sm"
              value={selectedBedType}
              onChange={(evt) => onBedTypeChange(evt.target.value)}>
              <SelectItem
                value="all"
                text={`${t('allBedTypes', 'All Bed Types')} (${totalCounts.occupied}/${totalCounts.total})`}
              />
              {bedTypes.map((type) => {
                const count = bedTypeCounts.get(type.uuid) || { occupied: 0, total: 0 };
                return (
                  <SelectItem
                    key={type.uuid}
                    value={type.uuid}
                    text={`${type.displayName || type.name} (${count.occupied}/${count.total})`}
                  />
                );
              })}
            </Select>
          </div>
          <div className={styles.viewToggleContainer}>
            <ContentSwitcher
              size="sm"
              selectedIndex={viewMode === 'card' ? 0 : 1}
              onChange={(data) => onViewModeChange(data.name as 'card' | 'list')}>
              <IconSwitch name="card" text={t('cardView', 'Card')}>
                <Copy size={16} />
              </IconSwitch>
              <IconSwitch name="list" text={t('listView', 'List')}>
                <Table size={16} />
              </IconSwitch>
            </ContentSwitcher>
          </div>
        </div>
      </div>
      {childLocations.length > 0 ? (
        <div className={styles.subTabs}>
          <Tabs selectedIndex={selectedChildIndex} onChange={handleChildTabChange}>
            <TabList className={styles.wardSubTabList} aria-label={t('wardSubTabs', 'Ward sub-tabs')}>
              {childLocations.map((ward) => (
                <Tab key={ward.uuid}>{ward.display}</Tab>
              ))}
            </TabList>
          </Tabs>
        </div>
      ) : null}
    </div>
  );
};

export default WardViewTabs;
